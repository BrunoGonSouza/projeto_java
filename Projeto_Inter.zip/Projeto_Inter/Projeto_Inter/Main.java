package Projeto_Inter;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
      int menu_principal;
      int menu_area;
      int menu_perimetro;
      int menu_volume;

      Formula f1;
      f1 = new Formula();

    while (true) {
      menu_principal = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite 1 para calculo de area: \nDigite 2 para calculo de perimetro:\nDigite 3 para calculo de volume:\nDigite 4 para calculo de raiz:"));
      
      switch (menu_principal) {
        case 1:
          menu_area = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 para calculo de área do triângulo: \nDigite 2 para calculo de área do quadrado: \nDigite 3 para calculo de área do cone: \nDigite 4 para calculo de área do paralelepipedo: \nDigite 5 para calculo de área do cilindro: \nDigite 6 para retornar ao menu principal"));
          
          break;
        case 2:
          menu_perimetro = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 para calculo de perimetro do triângulo: \nDigite 2 para calculo de perimetro do quadrado: \nDigite 3 para retornar ao menu principal"));

          break;

        case 3:
         menu_volume = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite 1 para calculo de volume do cone: \nDigite 2 para calculo de volume do cilindro: \nDigite 3 para calculo de volume do paralelepipedo: \nDigite 4 para retornar ao menu principal"));

         
          break;

        case 4:
          f1.entradaDados();
          f1.calculoDeRaiz();
          break;
       
        default:
          JOptionPane.showMessageDialog(null, "Opção invalida");
          break;
      }
    
    }
  }
}