package Projeto_Inter;

public class Paralelepipedo {
    float comprimento;
    float largura;
    float altura;
}
