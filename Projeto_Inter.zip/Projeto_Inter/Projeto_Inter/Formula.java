package Projeto_Inter;

import javax.swing.JOptionPane;

public class Formula{
    int a;
    int b;
    int c;
    double delta;
    double x1;
    double x2;
    
    
    // int a, int b, int c
    public Formula(){};

    public void entradaDados(){
        a = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de A: "));
        b = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de B: "));
        c = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o valor de C: "));
    }
   
    public double calculoDeRaiz(){
        delta = (b * b) - (4 * a * c);
        if (delta > 0){
            x1 = ((-b) + Math.sqrt(delta)) / (2 * a);
            x2 = ((-b) - Math.sqrt(delta)) / (2 * a);
            JOptionPane.showMessageDialog(null, "X1 = " + x1 + "\nX2 = " + x2 + "\nDelta = " + delta);
        } else {
            JOptionPane.showMessageDialog(null, "Não tem raiz");
        }
        return delta;
    }
    // public double getX1(){
    //     x1 = (-b + delta * (1/2) * (1/2) / (2 * a));
    //     return x1;
    // }
    // public double getX2(){
    //     x2 = (-b + delta * (1/2) * (1/2) / (2 * a));
    //     return x2;
    // }

    // public void imprimeDados(){
    //     JOptionPane.showMessageDialog(null, "Delta: " + this.delta + "\nX1: " + this.x1 + "\nX2: " + this.x2 );
    // }
}