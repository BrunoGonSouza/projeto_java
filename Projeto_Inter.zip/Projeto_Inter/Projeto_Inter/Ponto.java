package Projeto_Inter;

public class Ponto {
    
}