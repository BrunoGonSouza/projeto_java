package Projeto_Inter;

public class Cilindro {
    float area_lateral;
    float area_base;
    float altura;
}
