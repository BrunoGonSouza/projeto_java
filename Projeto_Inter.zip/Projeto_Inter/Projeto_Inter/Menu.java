package Projeto_Inter;

public class Menu {
    int menu_principal;
    int menu_area;
    int menu_perimetro;
    int menu_volume;
}
