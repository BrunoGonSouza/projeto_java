package Projeto_Inter;

public class Triangulo {
    float base;
    float altura;
    float lado;
}


