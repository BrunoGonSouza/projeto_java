package Projeto_Inter;

public class Quadrado {
    float lado;
    float base;
    float altura;
}
