package Projeto_Inter;

public class Cone {
    float altura;
}
